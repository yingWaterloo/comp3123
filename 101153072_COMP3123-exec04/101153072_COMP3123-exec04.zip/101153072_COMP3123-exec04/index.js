const express = require('express');
const app = express();
const path = require('path');

const SERVER_PORT = process.env.PORT || 3000;

// ✅ Serve static files directly from /public at the root URL
app.use(express.static(path.join(__dirname, 'public')));

// Middleware (optional, for parsing JSON/form data)
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
//http://localhost:3000/
app.get("/", (req, res) => {
    res.send("Hello Express JS");
})

//http://localhost:3000/index.html
// app.get("/index.html", (req, res) => {
//     res.sendFile(__dirname + "/public/index.html")
// })

//http://localhost:3000/hello
app.get("/hello", (req, res) => {
    res.send("Hello Express JS")
})

//http://localhost:3000/about
app.get("/about", (req, res) => {
    // res.send("<h1>About Page</h1>")
    //res.writeHead(200, {'Content-Type': 'text/html'});
    //res.send("<h1>About Page</h1>")
     res.status(200).send("<h1>About Page</h1>")
})

//http://localhost:3000/college
app.get("/college", (req, res) => {
    const college = {
        method: "GET",
        name: "George Brown College",
        location: "Toronto, Canada",
        established: 1967
    }

    // res.send(college);
    res.json(college);
})

//http://localhost:3000/college
app.post("/college", (req, res) => {
    const college = {
        method: "POST",
        name: "George Brown College",
        location: "Toronto, Canada",
        established: 1967
    }

    // res.send(college);
    res.json(college);
})

//http://localhost:3000/college
app.put("/college", (req, res) => {
    const college = {
        method: "PUT",
        name: "George Brown College",
        location: "Toronto, Canada",
        established: 1967
    }

    // res.send(college);
    res.json(college);
})

//http://localhost:3000/college
app.delete("/college", (req, res) => {
    const college = {
        method: "DELETE",
        name: "George Brown College",
        location: "Toronto, Canada",
        established: 1967
    }

    // res.send(college);
    res.json(college);
})

//Query Parameters
//http://localhost:3000/student?firstname=John&lastname=Wu
//req.query
app.get("/student", (req, res) => {
    if(req.query == {} || !req.query.firstname || !req.query.lastname) {
        return res.status(400).json({ error: "Missing query parameters" });
    }
    console.log(req.query);
    // const { name, age } = req.query;
    const firstname = req.query.firstname;
    const lastname = req.query.lastname;

    res.type('application/json');
    res.json({ status: true, data: { firstname: firstname, lastname: lastname }});
})

//Path Parameters
//http://localhost:3000/student/John/Wu
//req.params
app.get("/student/:firstname/:lastname", (req, res) => {
    const { firstname, lastname } = req.params;

    res.type('application/json');
    res.json({ status: true, data: { firstname, lastname }});
});
app.post("/student/:firstname/:lastname", (req, res) => {
    console.log(req.params);
    
    // Validate path parameters
    if(req.params.firstname === undefined || req.params.lastname === undefined) {
        res.status(400);
        return res.send({status: false, message: 'Bad Request: firstname and lastname are required'});
    }

    const { firstname, lastname } = req.params;
    res.type('application/json');
    res.json({ status: true, data: { firstname:firstname, lastname:lastname }});
})

//Body Parameters as JSON
//req.body
//http://localhost:3000/student
//POST
//Content-Type: application/json
//Body
/*
    {
        "name": "John",
        "age": 25
    }
*/
app.post("/student", (req, res) => {
    const student = req.body;
    console.log(student);
    
    const { firstname, lastname } = student;
    
    if(!student.firstname || !student.lastname) {
        return res.status(400).json({ error: "Missing body parameters" });
    }

    res.json({
        firstname: student.firstname,
        lastname: student.lastname
    })
})

app.listen(SERVER_PORT, () => {
    // console.loog("Server stareted");
    console.log(`Server is running on http://localhost:${SERVER_PORT}`);
});